package com.Talentum.TalentumApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalentumApplicationTests {

	@Test
	void contextLoads() {
	}

}
